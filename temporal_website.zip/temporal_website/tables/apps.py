from django.apps import AppConfig


class TablesConfig(AppConfig):
    name = 'tables'
