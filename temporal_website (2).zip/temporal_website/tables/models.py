from django.db import models

# Create your models here.
class Entry(models.Model):
    title = models.CharField(max_length=100, verbose_name="full name")
    abstract = models.CharField(max_length=100, verbose_name="full name")
    authors = models.CharField(max_length=100, verbose_name="full name")
    keywords = models.CharField(max_length=100, verbose_name="full name")
    affiliation = models.CharField(max_length=100, verbose_name="full name")
    month = models.CharField(max_length=100, verbose_name="full name")
    link = models.CharField(max_length=100, verbose_name="full name")
    journal_name = models.CharField(max_length=100, verbose_name="full name")
    year = models.IntegerField()
    volume = models.IntegerField()
    issue = models.IntegerField()

