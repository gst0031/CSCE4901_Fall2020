from django.apps import AppConfig


class WebpageConfig(AppConfig):
    name = 'webpage'
